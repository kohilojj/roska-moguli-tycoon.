# Roska Moguli Tycoon Ultra Edition

## Käyttö

### Frontend
Avaa `index.html` selaimessa.

### Backend
1. Mene `backend` kansioon
2. Muokkaa `server.js` ja lisää oma MongoDB Atlas connection string `uri` muuttujaan.
3. Aja:
```bash
npm install
node server.js
```
4. Nyt peli voi hakea leaderboardin osoitteesta `http://localhost:3000/leaderboard`
